/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employees_retrieve;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author mphoz
 */
public class DB_Connect {
    Connection conn = null;
    public Connection DBConnect(){
        try{
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/event_mate","root",""); 
            
            //conn = DriverManager.getConnection("jdbc:mysql://hcmkbooks.000webhostapp.com/:3306/id10544368_e_v_mate", "id10544368_mphozamikosi","6bdmPi4h9683WHM");
            //conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/id6796584_gooddeals_market", "id6796584_root","mK19961127+");

            return conn;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
            
    }
    
}
